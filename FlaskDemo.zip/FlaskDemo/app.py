from flask import Flask,render_template,request,redirect,url_for
from flask.globals import request
from flask.helpers import url_for
from werkzeug.utils import redirect

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/bingo')
def bingo():
    return render_template("bingo.html")
@app.route('/welcome')
def welcome():
    return render_template('welcome.html')
@app.route('/login',methods=['POST','GET'])
#def login():
#   if request.method == 'POST':
#        user = request.form['uname']
#        return redirect(url_for('success',name=user))
#    else:
#        user = request.args.get['uname']
#        return redirect(url_for('success',name=user))
def login():
    if request.method == 'POST':
         user = request.form['uname']
         return render_template('login.html', name=user)
    else:
        user = request.args.get['uname']
        return render_template('login.html', name=user)


@app.route('/simplecalculator',methods=['POST','GET'])
def simplecalculator():
    return render_template('calculator.html')
    
@app.route('/result',methods=['POST','GET'])
def result():
    if request.method == 'POST':
         num1 = int(request.form['a'])
         num2 = int(request.form['b'])
         res = num1 + num2
         return render_template('result.html', result=res)
    else:
        num1 = int(request.args.get['a'])
        num2 = int(request.args.get['b'])
        res = num1 + num2
        return render_template('result.html', result=res)


@app.route('/success/<name>')
def success(name):
    return "Hello %s " % name

if __name__=="__main__":
    app.run(debug=True)